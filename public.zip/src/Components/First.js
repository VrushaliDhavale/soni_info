// import React,{Component} from "react";

// import '../App.css';
// class First extends Component{
//     render(){
//         return (
//    <div className="country">
//        <h1>India</h1>
//             <h2>New Delhi</h2>
//    </div>
            
     
  

            
//         )
//     }
// }
// export default First;